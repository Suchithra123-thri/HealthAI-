from flask import Flask, request, jsonify
from flask_cors import CORS
from ibm_watsonx_ai.foundation_models import Model
from ibm_watsonx_ai import IAMTokenManager
from dotenv import load_dotenv
import os

app = Flask(__name__)
CORS(app)
load_dotenv()

API_KEY = os.getenv("API_KEY")
PROJECT_ID = os.getenv("PROJECT_ID")
MODEL_ID = 'granite-13b-chat-v2'

@app.route('/ask', methods=['POST'])
def ask_healthai():
    try:
        data = request.json
        user_question = data.get("question")

        if not user_question:
            return jsonify({"error": "Question is required"}), 400

        model = Model(model_id=MODEL_ID, credentials={"apikey": API_KEY, "project_id": PROJECT_ID})
        prompt = f"You are HealthAI, an intelligent healthcare assistant.\nQ: {user_question}\nA:"
        response = model.generate(prompt=prompt)

        return jsonify({"response": response})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({"status": "ok"})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
