# 🩺 HealthAI: Intelligent Healthcare Assistant

HealthAI is a mobile-friendly Generative AI chatbot built using IBM Watsonx.ai and the Granite LLM. It answers health-related questions like symptoms, first-aid, and medical term explanations.

## 🧠 Powered By:
- IBM Watsonx.ai (Granite 13B Chat model)
- Python + Flask
- HTML + CSS (mobile-responsive)
- Docker (for deployment on IBM Code Engine)

## 📦 How to Run Locally

```bash
cd backend
pip install -r requirements.txt
python app.py
```

Then open `frontend/index.html` in a browser.

### 🔐 Setup Credentials
Create a `.env` file inside `/backend` and add:

```env
API_KEY=your-api-key-here
PROJECT_ID=your-watsonx-project-id
```

## 🚀 Deploy on IBM Code Engine

1. Push code to GitHub: https://github.com/Suchithra123-thri/healthai-assistant
2. Connect repo to IBM Code Engine
3. Use `deploy/Dockerfile`
4. Set environment variables:
   - `API_KEY`
   - `PROJECT_ID`

## 🧪 Test API

```bash
POST https://healthai-app.xxxx.codeengine.appdomain.cloud/ask
{
  "question": "What is the treatment for fever?"
}
```
